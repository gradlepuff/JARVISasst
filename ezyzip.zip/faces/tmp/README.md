Extracted and aligned faces will be stored here
